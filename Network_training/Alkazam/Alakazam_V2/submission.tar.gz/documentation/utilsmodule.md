utils module
Utility functions for converting JSON and dictionary data to dataclass instances. These helpers are used by the API layer to build nested dataclasses from engine responses.

utils.json_to_dataclass(bs, cls)
Convert a JSON byte string to a dataclass instance.

This function decodes the JSON bytes and uses to_dataclass() to recursively convert the resulting dictionary to a dataclass instance.

Parameters
:
bs (bytes) – JSON data in bytes.

cls (type) – The target dataclass type.

Returns
:
An instance of the target dataclass.

Return type
:
Any

utils.to_dataclass(dic, cls)
Convert a dictionary to a dataclass instance recursively.

This function matches keys in the dictionary to the fields of the given dataclass cls, and recursively constructs nested dataclass instances if needed.

Parameters
:
dic (dict) – The source dictionary.

cls (type) – The target dataclass type.

Returns
:
An instance of the target dataclass, or None if input is None.

Return type
:
Any